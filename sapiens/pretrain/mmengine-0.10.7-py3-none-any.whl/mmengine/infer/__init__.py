# Copyright (c) OpenMMLab. All rights reserved.
from .infer import BaseInferencer

__all__ = ['BaseInferencer']
